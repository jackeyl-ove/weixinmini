var path = require('path');

module.exports = {
  staticPath: path.resolve(__dirname, '..', 'dist'),
  rootPath: path.resolve(__dirname, '..'),
  srcPath: path.resolve(__dirname, '..', 'src'),
  appPath: path.resolve(__dirname, '../src', 'lib')
};
